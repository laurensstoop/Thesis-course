#################################################################################################
#																								#
#	A model simulating a 2D Ising Model															#
#																								#
#	This software is made under the GNU General Public License, version 3 (GPL-3.0)				#
#																								#
#################################################################################################

# import the packages needed
import numpy as np
import random as random
import math as math

# Seed the random generator to make sure we can compare the system during building and testsing
random.seed(123456789)

# For now ask for keyboard input, can be rewritten to use a file
def Input():
	# Some variables are used by multiple functions, instead of returning global can be used
	global n
	global m
	global imax
	global beta
	# the number of particles can be set and is not bound by restrictions. So two different values are taken
	print("Give n")
	n = int(raw_input())
	print("Give m")
	m = int(raw_input())
	# there is a maximal number of itterations
	print("Give imax")
	imax = int(raw_input())
	# for the boltzmann distribution T is needed
	print("Give T")
	T = float(raw_input())
	# put in the minus here, because not sure if the if takes it
	beta = -1/T

# a function to make the initial system A. For now the initial system is random with 50/50 distribution
# The array has no values on the edges, so the system can be ...
def Initialize():
	global A
	# makes a array full of A's
	A = np.zeros((n+2, m+2))
	# replace the zero's by +- 1
	for i in range(1, n+1):
		for j in range(1, m+1):
			if random.random() > 0.5:
				A[i][j] = 1
			else: A[i][j] = -1

# A function to set the borders. These are the same as the last edge on the other side
def CorrectBorders():
	for i in range(1, n+1):
		A[i][0] = A[i][m]
	for i in range(1, n+1):
		A[i][m+1] = A[i][1]
	for i in range(1, m+1):
		A[0][i] = A[n][i]
	for i in range(1, m+1):
		A[n+1][i] = A[1][i]

# The monte carlo function. Is choses one of the particles and changes it.
def ChangeRandom():
	global nchange
	global mchange
	nchange = random.randint(1, n)
	mchange = random.randint(1, m)
	A[nchange,mchange] = -A[nchange,mchange]

# For now the output is given by printing the array to the screen
def PrintA():
	for value in A:
		print(value)

# A function to calculate the change in Energy. So the energy is +1 if the new value is different from it's neighbour
def CalculatedE():
	dE = - A[nchange][mchange] * (A[nchange-1][mchange]+A[nchange+1][mchange]+A[nchange][mchange-1]+A[nchange][mchange+1])
	return dE

# See if the change is allowed by the the boltzmann distribution. No sure if it's correct. Some pass some don't
def CheckChange(dE):
	# the minus is in beta
	return beta*dE > math.log(random.random())


# Get Input from the user\a file
Input()
# Based on the input make the initial state of the system
Initialize()
# Make the borders correct
CorrectBorders()
# Write the initial system to an output file
PrintA()
#Start the itteration
for i in range(imax):
	# Change on of the values in the sample
	ChangeRandom()
	# If the changed particle is on the edge of the sample, the borders have to be redrawn.
	if nchange == 1 or nchange == n or mchange == 1 or mchange == m:
	# Checked to work with nchange and mchange in the corners
		CorrectBorders()
	print(nchange, mchange)
	PrintA()
	# Calculate the energy change due to the change
	dE = CalculatedE()
	print("dE =", dE)
	# Check if the change is allowed if not discard the change and do the next itteration
	if not CheckChange(dE):
		print("Nope")
	else:
		print("Yeah")
	print("\n")






#To do	

	# Check if the system is in equillibrium if not do next itteration

	# Write out the wanted output for this itteration

	# See if done with the itteration, else do next itteration

	# Write away the output

